<?php 

function bbut_number_field( $name, $value, $field, $settings ) {
	
    echo '<input type="number" class="text text-full" name="' . $name . '" value="' . $value . '" placeholder="' . $field['placeholder'] . '" />';
}
add_action( 'fl_builder_control_bbut-number', 'bbut_number_field', 1, 4 );