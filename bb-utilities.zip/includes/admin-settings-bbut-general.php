<div id="fl-bbut-form" class="fl-settings-form bbut-fl-settings-form">

	<h3 class="fl-settings-form-header"><?php echo __( 'BB Utilities - General Settings', 'bbut' ); ?></h3>

	<form id="bbut-form" action="<?php FLBuilderAdminSettings::render_form_action( 'bbut' ); ?>" method="post">

		<div class="fl-settings-form-content">

			<?php

				$bbut = BB_Utilities::get_builder_bbut();

				$bbut_modules_used = $bbut_tracking = '';
				if( is_array($bbut) ) {
					$bbut_modules_used	= ( array_key_exists( 'bbut-modules-used', $bbut ) && $bbut['bbut-modules-used'] == 1 )  ? ' checked' : '';
					$bbut_tracking	= ( array_key_exists( 'bbut-tracking', $bbut ) && $bbut['bbut-tracking'] == 1 )  ? ' checked' : '';
				} ?>

			<!-- Modules Used-->
			<div class="bbut-form-setting">
				<h4><?php echo __( 'Enable Modules Used', 'bbut' ); ?></h4>
				<p class="bbut-admin-help"><?php _e('Enable this setting to view the modules used in the page builder.', 'bbut'); ?></p>
				<label>					
					<input type="checkbox" class="bbut-modules-used" name="bbut-modules-used" value="" <?php echo $bbut_modules_used; ?> ><?php echo __( 'Enable Modules Used', 'bbut' ); ?>
				</label>
			</div>

			<!-- Tracking -->
			<div class="bbut-form-setting">
				<h4><?php echo __( 'Enable Tracking', 'bbut' ); ?></h4>
				<p class="bbut-admin-help"><?php _e('Enable this setting to add Google analytics event tracking to page builder buttons.', 'bbut'); ?></p>
				<label>					
					<input type="checkbox" class="bbut-tracking" name="bbut-tracking" value="" <?php echo $bbut_tracking; ?> ><?php echo __( 'Enable Tracking', 'bbut' ); ?>
				</label>
			</div>

		</div>

		<p class="submit">
			<input type="submit" name="fl-save-bbut" class="button-primary" value="<?php esc_attr_e( 'Save Settings', 'fl-builder' ); ?>" />
		</p>

		<?php wp_nonce_field('bbut', 'fl-bbut-nonce'); ?>

	</form>
</div>
