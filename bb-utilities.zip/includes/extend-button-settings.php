<?php
	function bbut_extend_button_settings( $form, $id ) {
	
		$button_setting_arr = array(
			'title'         => __('Tracking', 'bbut'),
			'sections'      => array(
				'general'       => array(
					'title'         => __( 'Options', 'bbut' ),
					'fields'        => array(
						'tracking_enabled' => array(
							'type'          => 'select',
							'label'         => __('Enabled', 'bbut'),
							'default'       => 'no',
							'options'       => array(
								'no'						=>	__( 'No', 'bbut' ),
								'yes'						=>	__( 'Yes', 'bbut' ),
							),
							'toggle'	=> array(
								'yes'				=> array(
									'fields'		=> array( 'tracking_event_category', 'tracking_event_action', 'tracking_event_label', 'tracking_event_value' )
								),
							)
						),
						'tracking_event_category' => array(
							'type'          => 'text',
							'label'         => __('Event Category', 'bbut'),
							'description'	=> __('(ex. Outbound Link)'),
							'help'			=> __('Google Analytics eventCategory field')
						),
						'tracking_event_action' => array(
							'type'          => 'text',
							'label'         => __('Event Action', 'bbut'),
							'description'	=> __('(ex. click)'),
							'help'			=> __('Google Analytics eventAction field')
						),
						'tracking_event_label' => array(
							'type'          => 'text',
							'label'         => __('Event Label', 'bbut'),
							'description'	=> __('(ex. X Campaign)'),
							'help'			=> __('Google Analytics eventLabel field')
						),
						'tracking_event_value' => array(
							'type'          => 'bbut-number',
							'label'         => __('Event Value', 'bbut'),
							'placeholder'   => '1',
							'help'			=> __('Google Analytics eventValue field')
						)
					)
				)
			)
		);
		
		if ( $id == 'button' || $id == 'cta' ) {
			// echo $id;
			// echo '<pre>'; print_r( $form ); echo '</pre>';
			array_splice( $form, 3, 0, array( 'tracking' => $button_setting_arr ) );
		}
		return $form;
	}