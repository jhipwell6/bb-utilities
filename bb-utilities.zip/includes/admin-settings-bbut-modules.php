<div id="fl-bbut-modules-used-form" class="fl-settings-form bbut-fl-settings-form">

	<h3 class="fl-settings-form-header"><?php echo __( 'Modules Used', 'bbut' ); ?></h3>

	<form id="bbut-form" action="<?php FLBuilderAdminSettings::render_form_action( 'bbut' ); ?>" method="post">

		<div class="fl-settings-form-content">

			<?php 
				$modules_used = BB_Utilities::bbut_used_modules();
				if( $modules_used ) :
			?>
			<div class="bbut-form-setting">
				<ul>
					<?php foreach( $modules_used as $module => $count ) : ?>
					<li><?php echo ucwords( str_replace( '-', ' ', $module ) ) . " ({$count})"; ?></li>
					<?php endforeach; ?>
				</ul>
				
			</div>
			<?php endif; ?>
		</div>

		<?php wp_nonce_field('bbut', 'fl-bbut-nonce'); ?>

	</form>
</div>