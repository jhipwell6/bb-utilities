<div id="fl-bbut-modules-used-form" class="fl-settings-form bbut-fl-settings-form">

	<h3 class="fl-settings-form-header"><?php echo __( 'Modules Used', 'bbut' ); ?></h3>

	<form id="bbut-form" action="<?php FLBuilderAdminSettings::render_form_action( 'bbut-modules-used' ); ?>" method="post">

		<div class="fl-settings-form-content">

			<?php 
				$module_categories = FLBuilderModel::get_categorized_modules();
				$modules_used = BB_Utilities::bbut_used_modules();
				if( $modules_used ) :
					foreach( $module_categories as $title => $modules ) :
			?>
			<div class="bbut-form-setting">
				<h4><?php echo $title; ?></h4>
				<ul>
					<?php
						foreach( $modules as $module ) :
							if( ! array_key_exists( $module->slug, $modules_used ) ) continue;
					?>
					<li><?php echo $module->name . " ({$modules_used[$module->slug]})"; ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
			<?php endforeach; ?>
			<?php endif; ?>
		</div>

		<?php wp_nonce_field('bbut-modules-used', 'fl-bbut-modules-used-nonce'); ?>

	</form>
</div>