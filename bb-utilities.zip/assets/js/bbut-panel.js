( function($){
	
	$('.fl-builder-bbut-clear-cache-button').on('click', function(){
		FLBuilder.ajax({
			action: 'bbut_clear_cache'
		}, function( response ) {
			console.log( response );
		});
	});
	
})( jQuery );