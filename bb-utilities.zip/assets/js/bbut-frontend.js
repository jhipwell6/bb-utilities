(function($){
	
	if( typeof ga === 'function' ) {
		$('.bbut-track-link .fl-button').click(function( e ){
			var target = $(this).closest('.bbut-track-link'),
				eCategory = target.attr('data-ga-event-category'),
				eAction = target.attr('data-ga-event-action'),
				eLabel = target.attr('data-ga-event-label'),
				eValue = target.attr('data-ga-event-value');
			
			ga('send', 'event', {
				eventCategory: eCategory,
				eventAction: eAction,
				eventLabel: eLabel,
				eventValue: eValue,
				transport: 'beacon'
			});
		});
	}
	
})(jQuery);