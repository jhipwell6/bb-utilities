<?php

/**
 * Plugin Name: BB Utilities
 * Description: A lightweight utility plugin for Beaver Builder
 * Version: 1.0
 * Author: Jason Hipwell
 * Author URI: thehip6@gmail.com
 * License: GPLv3 or later
 * Text Domain: bbut
 */
define( 'BBUT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'BBUT_PLUGIN_URL', plugins_url( '/', __FILE__ ) );


if( ! class_exists( 'BB_Utilities' ) ) {
	
	class BB_Utilities {
		
		/*
		* Constructor function that initializes required actions and hooks
		* @Since 1.0
		*/
		function __construct() {
			
			add_action( 'after_setup_theme', array( $this, 'bbut_init_plugin' ), 1 );
			
			add_filter( 'fl_builder_admin_settings_nav_items', array( $this, 'bbut_settings_nav_item' ) );
			add_action( 'fl_builder_admin_settings_render_forms', array( $this, 'bbut_settings_nav_form' ) );
			
			add_filter( 'fl_builder_render_js', array( $this, 'fl_bbut_render_js' ), 10, 3 );
			
		}
		
		function bbut_init_plugin() {
			if ( class_exists( 'FLBuilder' ) ) {

				//	Extend Button Settings
				require_once 'includes/extend-button-settings.php';
				require_once 'includes/field-number.php';
				add_filter('fl_builder_register_settings_form', 'bbut_extend_button_settings', 10, 2);
				
				add_filter( 'fl_builder_module_custom_class', array( $this, 'bbut_extend_button_settings_class' ), 10, 2);
				add_filter( 'fl_builder_module_attributes', array( $this, 'bbut_extend_button_settings_attrs' ), 10, 2);

			}
		}
		
		// Admin Settings
		function bbut_settings_nav_item( $items ) {

			$items['bbut-modules-used'] = array(
				'title' 	=> __( 'Modules Used', 'bbut' ),
				'show'		=> true,
				'priority'	=> 301
			);

			return $items;
		}
		function bbut_settings_nav_form( $items ) {

			include BBUT_PLUGIN_DIR . 'includes/admin-settings-bbut-modules.php';
		}
		
		function bbut_extend_button_settings_class( $class, $module ) {
			$module = $module->settings;
			if ( $module->tracking_enabled == 'yes' ) {
				$class = $class.' bbut-track-link';
			}
			return $class;
		}
		
		function bbut_extend_button_settings_attrs( $attrs, $module ) {
			$module = $module->settings;
			if ( $module->tracking_enabled == 'yes' ) {
				$attrs['data-ga-event-category'] = $module->tracking_event_category;
				$attrs['data-ga-event-action'] = $module->tracking_event_action;
				$attrs['data-ga-event-label'] = $module->tracking_event_label;
				$attrs['data-ga-event-value'] = $module->tracking_event_value;
			}
			return $attrs;
		}
		
		function fl_bbut_render_js( $js, $nodes, $global_settings ) {
			if ( class_exists( 'FLBuilder' ) ) {
				$temp_js = file_get_contents( BBUT_PLUGIN_DIR . 'assets/js/bbut-frontend.js' );
				$js = $temp_js.$js;

				return $js;
	    	}
		}
		
		// Render Functions
		static function bbut_used_modules() {
	
			if( ! is_admin() )
				return false;
			
			$meta_query = array( array(
				'key' => '_fl_builder_data',
				'compare' => 'EXISTS'
			) );
			$loop = new WP_Query( array( 'post_type' => 'any', 'posts_per_page' => -1, 'meta_query' => $meta_query ) );
			if( $loop->have_posts() ) {
				
				$modules_used = array();
				while( $loop->have_posts() ) { $loop->the_post();
					$data = get_post_meta( get_the_ID(), '_fl_builder_data', true );
					if( $data ) {
						foreach( $data as $object ) {
							if( $object->type != 'module' ) {
								continue;
							}
							
							$modules_used[] = $object->settings->type;
						}
					}
				}
				
				// return array_unique( $modules_used );
				return array_count_values( $modules_used );
			}
		}
		
	}
	new BB_Utilities();
	
}