<?php

/**
 * Plugin Name: BB Utilities
 * Description: A lightweight utility plugin for Beaver Builder
 * Version: 1.1
 * Author: Jason Hipwell
 * Author URI: thehip6@gmail.com
 * Text Domain: bbut
 */
define( 'BBUT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'BBUT_PLUGIN_URL', plugins_url( '/', __FILE__ ) );


if( ! class_exists( 'BB_Utilities' ) ) {
	
	class BB_Utilities {
		
		/*
		* Constructor function that initializes required actions and hooks
		* @Since 1.0
		*/
		function __construct() {
			
			add_action( 'after_setup_theme', array( $this, 'bbut_init_plugin' ), 1 );
			
			add_filter( 'fl_builder_admin_settings_nav_items', array( $this, 'bbut_settings_nav_item' ) );
			add_action( 'fl_builder_admin_settings_render_forms', array( $this, 'bbut_settings_nav_form' ) );
			$bbut = BB_Utilities::get_builder_bbut();
			if ( is_array( $bbut ) && array_key_exists( 'bbut-modules-used', $bbut ) && $bbut['bbut-modules-used'] == 1 ) {	
				add_filter( 'manage_pages_columns', array( $this, 'bbut_custom_pages_columns' ) );
				add_action( 'manage_pages_custom_column', array( $this, 'bbut_module_column_content' ), 10, 2 );
			}
			
			add_filter( 'fl_builder_render_js', array( $this, 'fl_bbut_render_js' ), 10, 3 );
			
			add_action( 'plugins_loaded', array( $this, 'init_hooks'), 20 );
			add_action( 'fl_builder_admin_settings_save', array( $this, 'save' ) );
			
		}
		
		function bbut_init_plugin() {
			if ( class_exists( 'FLBuilder' ) ) {

				//	Extend Button Settings
				$bbut = BB_Utilities::get_builder_bbut();
				if ( is_array( $bbut ) && array_key_exists( 'bbut-tracking', $bbut ) && $bbut['bbut-tracking'] == 1 ) {
					require_once 'includes/extend-button-settings.php';
					require_once 'includes/field-number.php';
				
					add_filter('fl_builder_register_settings_form', 'bbut_extend_button_settings', 10, 2);
					
					add_filter( 'fl_builder_module_custom_class', array( $this, 'bbut_extend_button_settings_class' ), 10, 2);
					add_filter( 'fl_builder_module_attributes', array( $this, 'bbut_extend_button_settings_attrs' ), 10, 2);
				}

			}
		}
		
		function init_hooks() {

			if ( class_exists( 'FLBuilder' ) ) {

				if ( isset( $_REQUEST['page'] ) && 'fl-builder-settings' == $_REQUEST['page'] ) {
					$this->save();
				}
			}
		}
		
		// Admin Settings
		static public function get_builder_bbut() {
			
			$bbut = FLBuilderModel::get_admin_settings_option( '_fl_builder_bbut', true );

			$defaults = array(
				'bbut-modules-used'	=> 1,
				'bbut-tracking'		=> 1
			);

			//	if empty add all defaults
			if( empty( $bbut ) ) {
				$bbut = $defaults;
			} else {

				//	add new key
				foreach( $defaults as $key => $value ) {
					if( is_array( $bbut ) && !array_key_exists( $key, $bbut ) ) {
						$bbut[$key] = $value;
					} else {
						$bbut = wp_parse_args( $bbut, $defaults );
					}
				}
			}

			return apply_filters( 'bbut_get_builder_bbut', $bbut );
		}
		
		function bbut_settings_nav_item( $items ) {

			$items['bbut'] = array(
				'title' 	=> __( 'BB Utilities', 'bbut' ),
				'show'		=> true,
				'priority'	=> 201
			);
			
			$bbut = BB_Utilities::get_builder_bbut();
			if ( is_array( $bbut ) && array_key_exists( 'bbut-modules-used', $bbut ) && $bbut['bbut-modules-used'] == 1 ) {
				$items['bbut-modules-used'] = array(
					'title' 	=> __( 'Modules Used', 'bbut' ),
					'show'		=> true,
					'priority'	=> 301
				);
			}

			return $items;
		}
		function bbut_settings_nav_form( $items ) {

			include BBUT_PLUGIN_DIR . 'includes/admin-settings-bbut-general.php';
			
			$bbut = BB_Utilities::get_builder_bbut();
			if ( is_array( $bbut ) && array_key_exists( 'bbut-modules-used', $bbut ) && $bbut['bbut-modules-used'] == 1 ) {
				include BBUT_PLUGIN_DIR . 'includes/admin-settings-bbut-modules.php';
			}
		}
		
		function save() {

			// Only admins can save settings.
			if( ! current_user_can( 'delete_users' ) ) {
				return;
			}

			if ( isset( $_POST['fl-bbut-nonce'] ) && wp_verify_nonce( $_POST['fl-bbut-nonce'], 'bbut' ) ) {

				$bbut['bbut-modules-used'] = false;
				if( isset( $_POST['bbut-modules-used'] ) ) {
					$bbut['bbut-modules-used'] = true;
				}

				$bbut['bbut-tracking'] = false;
				if( isset( $_POST['bbut-tracking'] ) ) {
					$bbut['bbut-tracking'] = true;
				}

				FLBuilderModel::update_admin_settings_option( '_fl_builder_bbut', $bbut, true );
			}

			// Clear all asset cache.
			FLBuilderModel::delete_asset_cache_for_all_posts();
		}
		
		
		
		function bbut_extend_button_settings_class( $class, $module ) {
			$module = $module->settings;
			if ( $module->tracking_enabled == 'yes' ) {
				$class = $class.' bbut-track-link';
			}
			return $class;
		}
		
		function bbut_extend_button_settings_attrs( $attrs, $module ) {
			$module = $module->settings;
			if ( $module->tracking_enabled == 'yes' ) {
				$attrs['data-ga-event-category'] = $module->tracking_event_category;
				$attrs['data-ga-event-action'] = $module->tracking_event_action;
				$attrs['data-ga-event-label'] = $module->tracking_event_label;
				$attrs['data-ga-event-value'] = $module->tracking_event_value;
			}
			return $attrs;
		}
		
		function fl_bbut_render_js( $js, $nodes, $global_settings ) {
			if ( class_exists( 'FLBuilder' ) ) {
				$temp_js = file_get_contents( BBUT_PLUGIN_DIR . 'assets/js/bbut-frontend.js' );
				$js = $temp_js.$js;

				return $js;
	    	}
		}
		
		// Render Functions
		static function bbut_used_modules() {
	
			if( ! is_admin() )
				return false;
			
			$meta_query = array( array(
				'key' => '_fl_builder_data',
				'compare' => 'EXISTS'
			) );
			$loop = new WP_Query( array( 'post_type' => 'any', 'posts_per_page' => -1, 'meta_query' => $meta_query ) );
			if( $loop->have_posts() ) {
				
				$modules_used = array();
				while( $loop->have_posts() ) { $loop->the_post();
					$data = FLBuilderModel::get_layout_data( 'published', $post_id );
					if( $data ) {
						foreach( $data as $object ) {
							if( $object->type != 'module' ) {
								continue;
							}
							
							$modules_used[] = $object->settings->type;
						}
					}
				}
				
				return array_count_values( $modules_used );
			}
		}
		
		function bbut_custom_pages_columns( $columns ) {

			$bbut_modules_column = array(
				'bbut_modules' => __( 'Modules', 'bbut' )
			);
			$columns = array_merge( $columns, $bbut_modules_column );

			return $columns;
		}
		
		function bbut_module_column_content( $column_name, $post_id ) {
			
			if ( $column_name == 'bbut_modules' ) {
				$modules_used = array();
				$data = FLBuilderModel::get_all_modules( $post_id );
				if( $data ) {
					foreach( $data as $object ) {
						$modules_used[] = $object->name;
					}
					$list = array_count_values( $modules_used );
					if( $list ) {
						$sep = '';
						foreach( $list as $module => $count ) {
							echo "{$sep}{$module} ({$count})";
							$sep = ', ';
						}
					}
				} else {
					echo 'N/A';
				}
			}
		}
		
	}
	new BB_Utilities();
	
}